﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Splash
{
    public partial class Splash : Form
    {
        public Splash()
        {
            InitializeComponent();
        }
        int i = 0;
        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void Tm_Tick(object sender, EventArgs e)
        {
            //MessageBox.Show("Olá");
            //lbl.Text = i++.ToString();
            //if (i -- 11) {         // fazer parar
            //  tm.Stop();
            //}
            
            }

        private void Tm_Tick_1(object sender, EventArgs e)
        {
            try
            {
                lbl.Text = pgb.Value++.ToString() + "%";

                if (pgb.Value == 100)
                {
                    //DIRECIONAR PARA TELA DE LOGIN
                    lbl.Text = "100%";
                    Tm.Stop();
                    this.Hide();
                    Login frmLogin = new Login();
                    frmLogin.Show();
                }
            }
            catch (Exception erro)
            {
                MessageBox.Show("Tratar o erro");
            }
        }
    }
    }

            
        

