﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Splash
{
    public partial class MenuP : Form
    {
        public MenuP()
        {
            InitializeComponent();
        }

        private void navegadorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("");
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            process1.StartInfo.FileName = @"C:\Program Files\Google\Chrome\Application\chrome.exe";
            process1.Start();
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            process1.StartInfo.FileName = @"C:\Program Files (x86)\Microsoft\Edge\Application\msedge";
            process1.Start();
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            process1.StartInfo.FileName = @"C:\Program Files\Mozilla Firefox\Firefox.exe";
            process1.Start();
        }

        private void itemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            process1.StartInfo.FileName = @"C:\Program Files (x86)\Microsoft Office\root\Office16\WINWORD.exe";
            process1.Start();
        }

        private void excelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            process1.StartInfo.FileName = @"C:\Program Files (x86)\Microsoft Office\root\Office16\EXCEL";
            process1.Start();
        }
    }
}
